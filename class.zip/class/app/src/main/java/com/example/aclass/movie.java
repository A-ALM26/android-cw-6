package com.example.aclass;

public class movie {

    private String title = "Die hard" ;
    private String mainActor = "Bruce Willis" ;
    private Double movieRate = 8.8 ;
    int pgRate = 16 ;
    private String genre = "Action" ;

    public movie(String title, String mainActor, String movieRate, String  pgRate, String genre) {

    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getMainActor() {
        return mainActor;
    }

    public void setMainActor(String mainActor) {
        this.mainActor = mainActor;
    }

    public Double getMovieRate() {
        return movieRate;
    }

    public void setMovieRate(Double movieRate) {
        this.movieRate = movieRate;
    }

    public int getPgRate() {
        return pgRate;
    }

    public void setPgRate(int pgRate) {
        this.pgRate = pgRate;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }
}
